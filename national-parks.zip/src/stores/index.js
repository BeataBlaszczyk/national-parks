import useArticlesStore from './ArticlesStore';
import useParksStore from './ParksStore';

export {
    useArticlesStore,
    useParksStore
}